import type { VolumeMetadata } from '../services/api.js';
import { escapeHtml } from '../utils/html.js';

type Plane = 'axial' | 'coronal' | 'sagittal';
const planes: Plane[] = ['axial', 'coronal', 'sagittal'];
const labels: Record<Plane, string> = { axial: 'Axial', coronal: 'Coronal', sagittal: 'Sagittal' };

export function MRIViewer(props: { metadata?: VolumeMetadata | null; imageUrl?: string | null; plane?: Plane; index?: number; busy?: boolean }): string {
  const meta = props.metadata;
  if (!meta) return `<section class="card"><div class="section-title"><h2>MRI volume</h2><span class="pill blue">${props.busy ? 'Loading volume' : 'Available after analysis'}</span></div><p class="muted">${props.busy ? 'Reading the uploaded MRI volume.' : 'Upload and analyze an MRI to inspect its slices.'}</p><p class="fine-print">No validated lesion segmentation available.</p></section>`;
  const plane = props.plane || 'axial';
  const descriptor = meta.planes[plane];
  const index = props.index ?? Math.floor((descriptor?.slice_count || 1) / 2);
  return `<section class="card mri-viewer"><div class="section-title"><div><p class="eyebrow">MRI VOLUME</p><h2>MRI volume</h2></div><span class="pill blue">${escapeHtml(meta.modality)}</span></div><div class="viewer-image">${props.imageUrl ? `<img src="${escapeHtml(props.imageUrl)}" alt="${labels[plane]} MRI slice ${index + 1}" />` : '<div class="empty">Slice unavailable</div>'}</div><p class="fine-print">No validated lesion segmentation available.</p><div class="viewer-controls"><div class="segmented">${planes.map(key => `<button class="button ${key === plane ? 'primary' : ''}" data-view-plane="${key}">${labels[key]}</button>`).join('')}</div><label>Slice <input data-view-slice type="range" min="0" max="${Math.max(0, descriptor.slice_count - 1)}" value="${index}"><span>${index + 1} / ${descriptor.slice_count}</span></label><label>Zoom <input data-view-zoom type="range" min="0.5" max="3" step="0.1" value="1"><span>1.0×</span></label></div><div class="viewer-metadata"><span>Orientation <b>${labels[plane]}</b></span><span>Dimensions <b>${meta.dimensions.join(' × ')}</b></span><span>Voxel spacing <b>${meta.spacing_mm.join(' × ')} mm</b></span></div></section>`;
}
